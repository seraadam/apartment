# Udacity Carnival Starter Project

## Versions
- Patch 2017.1.0p4
- GVR Unity SDK v1.70.0
